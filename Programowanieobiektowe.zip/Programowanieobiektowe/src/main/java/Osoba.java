import java.sql.SQLOutput;

public class Osoba {

    public String imię;
    public String nazwisko;
    public int wiek;

    public void przedstawSię() {
        System.out.println
                ("Nazywam się " + imię + " " + nazwisko +
                        ". Mam " + wiek + " lat.");

    }

}
