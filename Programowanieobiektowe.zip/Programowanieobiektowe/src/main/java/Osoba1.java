public class Osoba1 {
    public static void main(String[] args) {
        Osoba Osoba1 = new Osoba();
        Osoba1.imię = "Agnieszka";
        Osoba1.nazwisko = "Nowak";
        Osoba1.wiek = 25;
        Osoba1.przedstawSię();
    }
}
