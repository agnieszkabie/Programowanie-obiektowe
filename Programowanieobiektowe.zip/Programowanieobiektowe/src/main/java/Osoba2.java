public class Osoba2 {
    public static void main(String[] args) {
        Osoba Osoba2 = new Osoba();
        Osoba2.imię = "Marek";
        Osoba2.nazwisko = "Kowalski";
        Osoba2.wiek = 30;
        Osoba2.przedstawSię();
    }
}