public class Firma {
    public static void main(String[] args) {
        Pracownik pracownik = new Pracownik();
        System.out.println("Imię: "+pracownik.imie);
        System.out.println("Nazwisko: "+pracownik.nazwisko);
        System.out.println("Wypłata: "+pracownik.wyplata);

        Szef szef = new Szef();
        
        szef.imie = "Karol";
        szef.nazwisko = "Krawczyk";
        szef.wyplata = 9000;
        szef.premia = 2000;
        System.out.println("Imię: "+ szef.imie);
        System.out.println("Nazwisko: "+szef.nazwisko);
        System.out.println("Wypłata "+szef.wyplata);
        System.out.println("Premia: "+szef.premia);

    }
}
