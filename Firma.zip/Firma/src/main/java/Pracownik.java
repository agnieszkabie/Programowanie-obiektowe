public class Pracownik {
    String imie;
    String nazwisko;
    int wyplata;

    public Pracownik () {
        imie = "Jan";
        nazwisko = "Kowalski";
        wyplata = 3000;
    }
}
