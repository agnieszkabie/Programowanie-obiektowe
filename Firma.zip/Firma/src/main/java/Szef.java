public class Szef extends Pracownik {
    int premia;


}
