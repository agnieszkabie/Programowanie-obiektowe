public class UstawPunkty {
    public static void main(String[] args) {
        Punkty punkty = new Punkty();
        punkty.ustawX(10);
        punkty.ustawY (20);

        System.out.println("Współrzędne punktu to ("+ punkty.wspX+ ", "+ punkty.wspY+")" );
    }
}
