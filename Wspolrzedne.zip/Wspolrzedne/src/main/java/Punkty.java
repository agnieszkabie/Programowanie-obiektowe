public class Punkty {
    int wspX;
    int wspY;

    void ustawX(int x) {
        wspX = x;}

        void ustawY(int y) {
            wspY = y; }

        int dajX() {
            return wspX;}

            int dajY(){
                return wspY;
            }
        }
